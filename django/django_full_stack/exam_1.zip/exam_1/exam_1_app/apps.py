from django.apps import AppConfig


class Exam1AppConfig(AppConfig):
    name = 'exam_1_app'
