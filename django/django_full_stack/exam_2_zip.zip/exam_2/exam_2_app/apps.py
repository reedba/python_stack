from django.apps import AppConfig


class Exam2AppConfig(AppConfig):
    name = 'exam_2_app'
