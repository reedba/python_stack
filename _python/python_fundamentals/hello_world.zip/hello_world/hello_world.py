print("Hello World!")

x = "Hello Python"
print(x)
y = 42
print(y)

name = "Brandon Reed"

print("Hello", name)

print("Hello "+ name)

print("Hello!",777)

num = 777

print(f"Hello! {num}")

statement = "Hello! 777"

print(statement)

food1 = "pizza"
food2 = "ice cream"

print("I love to eat %s and %s" % (food1,food2))

print(f"I love to eat {food1} and {food2}")

print(str.upper(food1))

print(str.capitalize(food2))